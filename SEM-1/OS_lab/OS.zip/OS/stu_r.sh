#!/bin/bash

it=0

while [[ $op -lt 7 ]]; do
    echo "----------------------------------------------"
    echo "1)Create Database "
    echo "2)Add Records "
    echo "3)Display Records "
    echo "4)Search Records "
    echo "5)Delete Records "
    echo "6)Modify Records "
    echo "7)Exit "
    echo "----------------------------------------------"
    echo
    read -p "Enter Your Choice: " op
    echo "----------------------------------------------"
    echo

    case "$op" in

    1)
        read -p "Enter The Name for the Database: " db
        touch "$db"
        ;;

    2)
        read -p "In Which Database Do You Want To Add Records: " db
        read -p "Enter The Number Of Records: " n
        while [[ $it -lt $n ]]; do

            read -p "Enter Id: " id1

            read -p "Enter Name: " nm
            pal="^[A-Za-z]"
            while [[ ! $nm =~ $pal ]]; do
                read -p "Enter a Valid Name: " nm
            done

            read -p "Enter Address: " add
            pa="^[A-Za-z0-9]"
            while [[ ! $add =~ $pa ]]; do
                read -p "Enter a Valid Address: " add
            done

            read -p "Enter Phone Number: " ph
            pat="^[0-9]{10}$"
            while [[ ! $ph =~ $pat ]]; do
                read -p "Enter a Valid Phone Number: " ph
            done

            read -p "Enter Email: " em
            patem="^[a-z0-9._%-+]+@[a-z]+\.[a-z]{2,4}$"
            while [[ ! $em =~ $patem ]]; do
                read -p "Enter a Valid Email: " em
            done

            echo "$id1,$nm,$add,$ph,$em" >>"$db"

            it=$(expr $it + 1)
            echo "$it Record Entered!!"
            echo
            echo "----------------------------------------------"
        done
        it=0
        ;;
    3)
        read -p "Enter Name Of The Database To Be Displayed: " db
        echo
        echo "----------------------------------------------"
        echo "Data: "
        echo
        cat $db
        echo
        ;;

    4)
        read -p "Enter Name Of The Database From Where To Search: " db

        read -p "Enter Email: " eml
        patem="^[a-z0-9._%-+]+@[a-z]+\.[a-z]{2,4}$"
        while [[ ! $eml =~ $patem ]]; do
            read -p "Enter a Valid Email: " eml
        done

        var="$(grep $eml $db)"

        if [[ "$var" == "" ]]; then
            echo "Record Not Found"
            echo
        else
            echo
            echo "Following Record Found:"
            echo "----------------------------------------------"
            echo $var
            echo "----------------------------------------------"
            echo
        fi
        ;;

    5)
        read -p "Enter Name Of Database: " db
        read -p "Enter id: " id1

        for lin in $(grep -n "$id1" $db); do
            echo "Record Is Being Fetch..."
        done

        if [[ $lin == "" ]]; then
            echo "Id Not Found"
        else
            for line in $(grep -n "$id1" $db); do

                if [[ $lin == $line ]]; then
                    lineRemove=${line:0:1}
                    sed -i -e "${lineRemove}d" $db
                    echo "Record removed"
                fi
            done
        fi
        lin=""
        line=""
        ;;

    6)
        read -p "Enter Name Of The Database: " db
        read -p "Enter Id: " id1

        for lin in $(grep -n "$id1" $db); do
            echo "Record Is Being Fetch..."
        done

        if [[ $lin == "" ]]; then
            echo "Id Not Found"
        else
            for line in $(grep -n "$id1" $db); do

                if [[ $lin == $line ]]; then
                    echo "\"id,name,address,mobile,email\""
                    read -p "Enter What Would You Like To change: " edit
                    linechange="${lin:0:1}s"
                    sed -i -e "$linechange/.*/$edit/" $db
                    echo "Record Edited"
                fi
            done
        fi
        ;;
    7)
        echo "Thank You"
        ;;
    *)
        echo "Invalid Input"
        ;;

    esac

done
