#include<stdio.h>
#include<sys/wait.h>
#include<unistd.h>

int main()
{
	if (fork() == 0)
	{
		printf("HC : HELLO! FROM CHILD\n");
	}
	else
	{
		printf("HP : HELLO! FROM PARENT\n");
		wait(NULL);
		printf("CT : CHILD HAS BEEN TERMINATED\n");
	}
	printf("BYE!\n");
	return 0;
}
