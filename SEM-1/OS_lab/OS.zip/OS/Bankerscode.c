#include <stdio.h>

int main() {
    int proc, res, i, j;

    // Input the number of processes and resource types
    printf("ENTER THE NUMBER OF PROCESSES: ");
    scanf("%d", &proc);
    printf("ENTER THE NUMBER OF RESOURCE TYPES: ");
    scanf("%d", &res);

    // Declare and initialize matrices and arrays
    int alloc[proc][res], max[proc][res], need[proc][res], avail[res];
    int finish[proc], safeSeq[proc], work[res];

    // Input the allocation matrix
    printf("ENTER THE CURRENTLY AVAILABLE RESOURCES OF EACH PROCESSES (ALLOCATION MATRIX):\n");
    for (i = 0; i < proc; i++) {
        printf("FOR PROCESS P%d: ", i);
        for (j = 0; j < res; j++) {
            scanf("%d", &alloc[i][j]);
        }
        finish[i] = 0;  // Initialize finish array
    }

    // Input the maximum matrix
    printf("NEED OF RESOURCES OF EACH PROCESS (MAXIMUM MATRIX):\n");
    for (i = 0; i < proc; i++) {
        printf("FOR PROCESS P%d: ", i);
        for (j = 0; j < res; j++) {
            scanf("%d", &max[i][j]);
            need[i][j] = max[i][j] - alloc[i][j];
        }
    }

    // Input the available resources
    printf("ENTER THE AVAILABLE RESOURCES:\n");
    for (i = 0; i < res; i++) {
        scanf("%d", &avail[i]);
        work[i] = avail[i];  // Initialize work array
    }

    // Find a safe sequence and display executed processes
    int count = 0;
    printf("\nProcesses executed in the safe sequence:\n");
    while (count < proc) {
        int found = 0;

        for (i = 0; i < proc; i++) {
            if (finish[i] == 0) {
                int canExecute = 1;

                for (j = 0; j < res; j++) {
                    if (need[i][j] > work[j]) {
                        canExecute = 0;
                        break;
                    }
                }

                if (canExecute) {
                    printf("PROCESS P%d EXECUTED\n", i);
                    printf("AVAILABLE = ");
                    for (j = 0; j < res; j++) {
                        work[j] += alloc[i][j];
                        printf("\t%d", work[j]);
                    }
                    printf("\n");

                    finish[i] = 1;
                    safeSeq[count++] = i;
                    found = 1;
                }
            }
        }

        if (!found) {
            printf("\nUnsafe state: No safe sequence exists.\n");
            break;
        }
    }

    // Display the safe sequence if it exists
    if (count == proc) {
        printf("\nSafe sequence: ");
        for (i = 0; i < proc; i++) {
            printf("P%d", safeSeq[i]);
            if (i < proc - 1) {
                printf(" -> ");
            }
        }
        printf("\n");
    }

    return 0;
}
