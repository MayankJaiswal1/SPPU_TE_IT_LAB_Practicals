#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

void sort(int a[11]);

int main(int argc, char *argv[])
{
    int pid;
    int i = 0, n = 10, search;
    int a[11];
    char *newarg[] = {"./sort_program", NULL}; // Replace with correct path to your sorting program
    FILE *f;

    printf("Enter array elements: \n");
    for (i = 1; i <= 10; i++)
        scanf("%d", &a[i]);

    printf("Enter value to find: \t");
    scanf("%d", &search);

    pid = fork();

    if (pid == 0)
    {
        printf("Child process executing %s\n", newarg[0]); // Debugging output
        sleep(1);
        execv(newarg[0], newarg);
        perror("execv"); // Print error if execv fails
        exit(1); // Terminate child process if execv fails
    }
    else
    {
        wait(NULL); // Wait for the child process to finish
        sort(a);
        f = fopen("sort.txt", "w");

        fprintf(f, "%d\n", search);

        for (i = 1; i <= n; i++)
        {
            fprintf(f, "%d ", a[i]);
        }

        fclose(f);
    }

    return 0;
}

void sort(int a[11])
{
    int n = 10, i, j, temp;

    for (i = 1; i <= n; i++)
    {
        for (j = i + 1; j <= n; j++)
        {
            if (a[i] > a[j])
            {
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
}
