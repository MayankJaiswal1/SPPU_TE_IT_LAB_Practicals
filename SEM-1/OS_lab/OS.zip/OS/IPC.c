#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>
#include<sys/wait.h>

int main(void){
	int fd1[2], nbytes=1, fd2[2], a=0;
	pid_t pid;
	char string[80];
	char readbuffer[80];
	char ch='a', ch1='\n';
	FILE *fp;
	
	pipe(fd1);   // PIPE CREATED
	pipe(fd2);   // PIPE CREATED
	
	/* error in fork */
	if((pid = fork()) == -1)
	{
		perror("fork");
		exit(1);
	}
	
	// Child Process
	if(pid == 0){
		close(fd1[1]);		// closing write end of pipe 1
		read(fd1[0], readbuffer, sizeof(readbuffer));   // reading filename through pipe 1
		fp = fopen(readbuffer, "r");
		close(fd1[0]);
		close(fd2[0]);
		printf("\nContents of %s are being sent to parent process through pipe 2...\n", readbuffer);
		
		while(a != -1)
		{
			a = fscanf(fp, "%c", &ch);
			write(fd2[1], &ch, sizeof(ch));		// writing contents of file on pipe2		
		}
		close(fd2[1]);		// closing write end of pipe 2
		exit(0);
	}
	
	// Child Process
	else
	{
		close(fd1[0]);		// closing read end of pipe 1
		printf("IN PARENT PROCESS...\n");
		printf("\nENTER NAME OF THE FILE: ");
		scanf("%s", string);
		printf("Filename is being sent by parent process to child process through pipe 1...\n");
		write(fd1[1], string, (strlen(string)+1));		// writing filename on pipe 1
		wait(0);
		close(fd1[1]);		// closing write end of pipe 1
		close(fd2[1]);		// closing write end of pipe 2
		
		printf("\nContents of %s are being received by parent process through pipe 2..\n\n", string);
		printf("IN PARENT PROCESS...\n");
		printf("\nRECEIVED MESSAGE: \n");
		
		while(nbytes != 0)
		{
			printf("%c", ch1);
			nbytes = read(fd2[0], &ch1, sizeof(ch1));		// reading file contents from pipe 2
			
		}
		close(fd2[0]);		//closing read end of pipe 2
	}
	
	return(0);
}
