#include <stdio.h>

int main() {
    int i, NOP, sum = 0, count = 0, y, quant, wt = 0, tat = 0, at[10], bt[10], temp[10];
    float avg_wt, avg_tat;

    printf("total number of processes in the system: ");
    scanf("%d", &NOP);

    y = NOP;

    for (i = 0; i < NOP; i++) {
        printf("\nENTER THE ARRIVAL AND BURST TIME OF PROCESS[%d]\n", i + 1);
        printf(" ARRIVAL TIME: \t");
        scanf("%d", &at[i]);
        printf(" BURST TIME: \t");
        scanf("%d", &bt[i]);
        temp[i] = bt[i];
    }

    printf("Enter Time Quantum (in ms): \t");
    scanf("%d", &quant);

    printf("\n PROCESS NO. \t\t BURST TIME \t\t TAT \t\t WT");

    for (sum = 0, i = 0; y != 0;) {
        if (temp[i] <= quant && temp[i] > 0) {
            sum = sum + temp[i];
            temp[i] = 0;
            count = 1;
        } else if (temp[i] > 0) {
            temp[i] = temp[i] - quant;
            sum = sum + quant;
        }
        if (temp[i] == 0 && count == 1) {
            y--;
            printf("\nPROCESS NO.[%d] \t\t %d\t\t\t %d\t\t %d", i + 1, bt[i], sum - at[i], sum - at[i] - bt[i]);
            wt = wt + sum - at[i] - bt[i];
            tat = tat + sum - at[i];
            count = 0;
        }
        if (i == NOP - 1) {
            i = 0;
        } else if (at[i + 1] <= sum) {
            i++;
        } else {
            i = 0;
        }
    }

    avg_wt = (float)wt / NOP;
    avg_tat = (float)tat / NOP;

    printf("\n\n AVERAGE TURNAROUND TIME: \t%f", avg_tat);
    printf("\n AVERAGE WAITING TIME: \t%f", avg_wt);

    return 0;
}

